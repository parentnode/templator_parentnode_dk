/*
Manipulator v0.9.1-full Copyright 2015 http://manipulator.parentnode.dk
js-merged @ 2016-01-12 09:43:49
*/

/*seg_seo_include.js*/

/*u.js*/
if(!u || !Util) {
	var u, Util = u = new function() {};
	u.version = "0.9.1";
	u.bug = u.nodeId = u.exception = function() {};
	u.stats = new function() {this.pageView = function(){};this.event = function(){};this.customVar = function(){};}
}

